# Proof-search arena

Scores are compared only within an identical target, snapshot, verifier, and execution profile.

C is canonical UTF-8 proof bytes; T is discovery + verification CPU seconds. Lower S=(C+100)*(T+1) is better.

## Target {4,5} — 3e103a918748c46f

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| routes-short | valid | N | 73 | 0.041529 | 0.039988 | 0.081517 | 187.102422 | 5.231656 |
| interleaved | valid | N | 73 | 0.042609 | 0.039630 | 0.082240 | 187.227443 | 5.232324 |
| interleaved | valid | N | 73 | 0.042188 | 0.040849 | 0.083037 | 187.365472 | 5.233061 |
| routes-short | valid | N | 73 | 0.042109 | 0.041046 | 0.083155 | 187.385803 | 5.233170 |
| interleaved | valid | N | 73 | 0.042219 | 0.041412 | 0.083630 | 187.468075 | 5.233609 |
| routes-short | valid | N | 73 | 0.042750 | 0.046544 | 0.089295 | 188.447953 | 5.238822 |
| evolved-prompt | valid | N | 73 | 0.114866 | 0.040787 | 0.155653 | 199.927902 | 5.297957 |
| evolved-prompt | valid | N | 73 | 0.121248 | 0.040129 | 0.161377 | 200.918286 | 5.302898 |
| evolved-prompt | valid | N | 73 | 0.129218 | 0.040272 | 0.169490 | 202.321704 | 5.309859 |
| mock-prompt-seed | valid | N | 73 | 0.137086 | 0.040551 | 0.177636 | 203.731097 | 5.316801 |
| mock-prompt-seed | valid | N | 73 | 0.137831 | 0.040734 | 0.178565 | 203.891754 | 5.317589 |
| mock-prompt-seed | valid | N | 73 | 0.139370 | 0.041766 | 0.181136 | 204.336523 | 5.319768 |
| evolved-policy | valid | N | 139 | 0.042296 | 0.037556 | 0.079852 | 258.084581 | 5.553287 |
| evolved-policy | valid | N | 139 | 0.043237 | 0.040425 | 0.083662 | 258.995130 | 5.556809 |
| increasing | valid | N | 139 | 0.045369 | 0.039580 | 0.084949 | 259.302859 | 5.557997 |
| evolved-policy | valid | N | 139 | 0.044253 | 0.041416 | 0.085669 | 259.474880 | 5.558660 |
| increasing | valid | N | 139 | 0.045715 | 0.040423 | 0.086138 | 259.586917 | 5.559092 |
| increasing | valid | N | 139 | 0.052566 | 0.041033 | 0.093599 | 261.370281 | 5.565938 |

evolved-policy: 3/3 valid; S min/median/max = 258.084581/258.995130/259.474880; stdev = 0.706186.
evolved-prompt: 3/3 valid; S min/median/max = 199.927902/200.918286/202.321704; stdev = 1.202826.
increasing: 3/3 valid; S min/median/max = 259.302859/259.586917/261.370281; stdev = 1.120662.
interleaved: 3/3 valid; S min/median/max = 187.227443/187.365472/187.468075; stdev = 0.120750.
mock-prompt-seed: 3/3 valid; S min/median/max = 203.731097/203.891754/204.336523; stdev = 0.313627.
routes-short: 3/3 valid; S min/median/max = 187.102422/187.385803/188.447953; stdev = 0.709333.

## Target {4,5,11} — c1926648b1444aae

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| interleaved | valid | P | 79 | 0.040946 | 0.038184 | 0.079129 | 193.164098 | 5.263540 |
| routes-short | valid | P | 79 | 0.042776 | 0.039354 | 0.082130 | 193.701295 | 5.266317 |
| interleaved | valid | P | 79 | 0.041363 | 0.040815 | 0.082178 | 193.709812 | 5.266361 |
| evolved-policy | valid | P | 79 | 0.042209 | 0.040359 | 0.082569 | 193.779827 | 5.266723 |
| routes-short | valid | P | 79 | 0.042542 | 0.040927 | 0.083470 | 193.941092 | 5.267554 |
| routes-short | valid | P | 79 | 0.042991 | 0.040535 | 0.083526 | 193.951091 | 5.267606 |
| evolved-policy | valid | P | 79 | 0.043260 | 0.040862 | 0.084122 | 194.057878 | 5.268156 |
| evolved-policy | valid | P | 79 | 0.042540 | 0.041788 | 0.084329 | 194.094815 | 5.268347 |
| interleaved | valid | P | 79 | 0.043093 | 0.041610 | 0.084704 | 194.161980 | 5.268693 |
| evolved-prompt | valid | P | 79 | 0.123021 | 0.039884 | 0.162905 | 208.160040 | 5.338307 |
| evolved-prompt | valid | P | 79 | 0.130513 | 0.039576 | 0.170089 | 209.445983 | 5.344466 |
| evolved-prompt | valid | P | 79 | 0.128669 | 0.041773 | 0.170441 | 209.508969 | 5.344767 |
| mock-prompt-seed | valid | P | 79 | 0.134418 | 0.041331 | 0.175749 | 210.459033 | 5.349291 |
| mock-prompt-seed | valid | P | 79 | 0.141565 | 0.039896 | 0.181461 | 211.481576 | 5.354138 |
| mock-prompt-seed | valid | P | 79 | 0.145152 | 0.041123 | 0.186275 | 212.343208 | 5.358204 |
| increasing | valid | P | 594 | 0.042249 | 0.040142 | 0.082391 | 751.179382 | 6.621644 |
| increasing | valid | P | 594 | 0.042537 | 0.042335 | 0.084872 | 752.901118 | 6.623934 |
| increasing | valid | P | 594 | 0.043477 | 0.041682 | 0.085159 | 753.100631 | 6.624199 |

evolved-policy: 3/3 valid; S min/median/max = 193.779827/194.057878/194.094815; stdev = 0.172189.
evolved-prompt: 3/3 valid; S min/median/max = 208.160040/209.445983/209.508969; stdev = 0.761274.
increasing: 3/3 valid; S min/median/max = 751.179382/752.901118/753.100631; stdev = 1.056360.
interleaved: 3/3 valid; S min/median/max = 193.164098/193.709812/194.161980; stdev = 0.499671.
mock-prompt-seed: 3/3 valid; S min/median/max = 210.459033/211.481576/212.343208; stdev = 0.943232.
routes-short: 3/3 valid; S min/median/max = 193.701295/193.941092/193.951091; stdev = 0.141422.

## Target {4,6} — d0c19552109dd807

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| interleaved | valid | P | 301 | 0.037021 | 0.036707 | 0.073728 | 430.564883 | 6.065098 |
| evolved-policy | valid | P | 301 | 0.037082 | 0.037064 | 0.074146 | 430.732425 | 6.065487 |
| evolved-policy | valid | P | 301 | 0.039132 | 0.035980 | 0.075112 | 431.119833 | 6.066386 |
| interleaved | valid | P | 301 | 0.037825 | 0.037338 | 0.075163 | 431.140532 | 6.066434 |
| evolved-policy | valid | P | 301 | 0.037975 | 0.037592 | 0.075567 | 431.302252 | 6.066809 |
| routes-short | valid | P | 301 | 0.038614 | 0.036973 | 0.075587 | 431.310402 | 6.066828 |
| routes-short | valid | P | 301 | 0.037560 | 0.038190 | 0.075750 | 431.375845 | 6.066980 |
| increasing | valid | P | 301 | 0.038582 | 0.037352 | 0.075934 | 431.449405 | 6.067150 |
| increasing | valid | P | 301 | 0.037348 | 0.038608 | 0.075956 | 431.458394 | 6.067171 |
| increasing | valid | P | 301 | 0.039055 | 0.037239 | 0.076294 | 431.593782 | 6.067485 |
| interleaved | valid | P | 301 | 0.039044 | 0.037394 | 0.076438 | 431.651753 | 6.067619 |
| routes-short | valid | P | 301 | 0.038134 | 0.038584 | 0.076718 | 431.763924 | 6.067879 |
| evolved-prompt | valid | P | 301 | 0.091125 | 0.037009 | 0.128134 | 452.381721 | 6.114526 |
| evolved-prompt | valid | P | 301 | 0.090989 | 0.037882 | 0.128872 | 452.677551 | 6.115180 |
| evolved-prompt | valid | P | 301 | 0.092279 | 0.038117 | 0.130396 | 453.288840 | 6.116530 |
| mock-prompt-seed | valid | P | 301 | 0.102132 | 0.038045 | 0.140177 | 457.210782 | 6.125145 |
| mock-prompt-seed | valid | P | 301 | 0.102435 | 0.038022 | 0.140457 | 457.323279 | 6.125391 |
| mock-prompt-seed | valid | P | 301 | 0.108251 | 0.037611 | 0.145861 | 459.490402 | 6.130118 |

evolved-policy: 3/3 valid; S min/median/max = 430.732425/431.119833/431.302252; stdev = 0.290993.
evolved-prompt: 3/3 valid; S min/median/max = 452.381721/452.677551/453.288840; stdev = 0.462611.
increasing: 3/3 valid; S min/median/max = 431.449405/431.458394/431.593782; stdev = 0.080886.
interleaved: 3/3 valid; S min/median/max = 430.564883/431.140532/431.651753; stdev = 0.543754.
mock-prompt-seed: 3/3 valid; S min/median/max = 457.210782/457.323279/459.490402; stdev = 1.284896.
routes-short: 3/3 valid; S min/median/max = 431.310402/431.375845/431.763924; stdev = 0.245143.

## Target {6,7} — e7f907ece0b85082

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| evolved-prompt | valid | N | 73 | 0.116832 | 0.040029 | 0.156861 | 200.136906 | 5.299002 |
| evolved-prompt | valid | N | 73 | 0.117837 | 0.040294 | 0.158131 | 200.356636 | 5.300099 |
| evolved-prompt | valid | N | 73 | 0.125471 | 0.039906 | 0.165377 | 201.610220 | 5.306336 |
| mock-prompt-seed | valid | N | 73 | 0.136674 | 0.039589 | 0.176263 | 203.493508 | 5.315634 |
| mock-prompt-seed | valid | N | 73 | 0.143569 | 0.041715 | 0.185284 | 205.054069 | 5.323274 |
| mock-prompt-seed | valid | N | 73 | 0.147573 | 0.039538 | 0.187111 | 205.370188 | 5.324814 |
| routes-short | valid | N | 139 | 0.043565 | 0.040043 | 0.083607 | 258.982115 | 5.556759 |
| interleaved | valid | N | 139 | 0.042890 | 0.040778 | 0.083668 | 258.996567 | 5.556815 |
| interleaved | valid | N | 139 | 0.043682 | 0.040081 | 0.083763 | 259.019317 | 5.556903 |
| routes-short | valid | N | 139 | 0.043526 | 0.040302 | 0.083828 | 259.034816 | 5.556962 |
| routes-short | valid | N | 139 | 0.042443 | 0.041528 | 0.083971 | 259.069105 | 5.557095 |
| interleaved | valid | N | 139 | 0.044065 | 0.040016 | 0.084081 | 259.095256 | 5.557196 |
| evolved-policy | valid | N | 139 | 0.047181 | 0.040828 | 0.088009 | 260.034121 | 5.560813 |
| evolved-policy | valid | N | 139 | 0.048733 | 0.039833 | 0.088566 | 260.167272 | 5.561325 |
| evolved-policy | valid | N | 139 | 0.047615 | 0.041307 | 0.088922 | 260.252338 | 5.561652 |
| increasing | valid | N | 139 | 0.062473 | 0.039895 | 0.102367 | 263.465810 | 5.573924 |
| increasing | valid | N | 139 | 0.061623 | 0.041900 | 0.103523 | 263.741898 | 5.574971 |
| increasing | valid | N | 139 | 0.063587 | 0.040731 | 0.104318 | 263.931996 | 5.575691 |

evolved-policy: 3/3 valid; S min/median/max = 260.034121/260.167272/260.252338; stdev = 0.109988.
evolved-prompt: 3/3 valid; S min/median/max = 200.136906/200.356636/201.610220; stdev = 0.794817.
increasing: 3/3 valid; S min/median/max = 263.465810/263.741898/263.931996; stdev = 0.234411.
interleaved: 3/3 valid; S min/median/max = 258.996567/259.019317/259.095256; stdev = 0.051678.
mock-prompt-seed: 3/3 valid; S min/median/max = 203.493508/205.054069/205.370188; stdev = 1.004756.
routes-short: 3/3 valid; S min/median/max = 258.982115/259.034816/259.069105; stdev = 0.043819.

## Coverage (separate from per-target scores)

- evolved-policy: 4/4 distinct tasks solved.
- evolved-prompt: 4/4 distinct tasks solved.
- increasing: 4/4 distinct tasks solved.
- interleaved: 4/4 distinct tasks solved.
- mock-prompt-seed: 4/4 distinct tasks solved.
- routes-short: 4/4 distinct tasks solved.
