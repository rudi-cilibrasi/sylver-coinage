# Proof-search arena

Scores are compared only within an identical target, snapshot, verifier, and execution profile.

C is canonical UTF-8 proof bytes; T is discovery + verification CPU seconds. Lower S=(C+100)*(T+1) is better.

## Target {6,7,11} — 12a0d60ee1ae5987

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| routes-short | valid | N | 79 | 0.043705 | 0.038250 | 0.081955 | 193.669953 | 5.266155 |
| interleaved | valid | N | 79 | 0.041777 | 0.040359 | 0.082136 | 193.702367 | 5.266323 |
| interleaved | valid | N | 79 | 0.042853 | 0.040091 | 0.082943 | 193.846879 | 5.267069 |
| routes-short | valid | N | 79 | 0.041989 | 0.041040 | 0.083029 | 193.862236 | 5.267148 |
| interleaved | valid | N | 79 | 0.042636 | 0.040598 | 0.083234 | 193.898884 | 5.267337 |
| routes-short | valid | N | 79 | 0.044380 | 0.040488 | 0.084868 | 194.191428 | 5.268844 |
| evolved-prompt | valid | N | 79 | 0.119024 | 0.039623 | 0.158647 | 207.397742 | 5.334638 |
| evolved-prompt | valid | N | 79 | 0.121798 | 0.040581 | 0.162378 | 208.065743 | 5.337854 |
| evolved-prompt | valid | N | 79 | 0.127936 | 0.040429 | 0.168365 | 209.137350 | 5.342991 |
| mock-prompt-seed | valid | N | 79 | 0.133203 | 0.040018 | 0.173221 | 210.006506 | 5.347139 |
| mock-prompt-seed | valid | N | 79 | 0.138642 | 0.040762 | 0.179404 | 211.113268 | 5.352395 |
| mock-prompt-seed | valid | N | 79 | 0.143070 | 0.041988 | 0.185058 | 212.125325 | 5.357177 |
| evolved-policy | valid | N | 148 | 0.043142 | 0.039726 | 0.082867 | 268.551132 | 5.593041 |
| evolved-policy | valid | N | 148 | 0.042871 | 0.040973 | 0.083844 | 268.793252 | 5.593943 |
| increasing | valid | N | 148 | 0.046091 | 0.041088 | 0.087179 | 269.620355 | 5.597015 |
| increasing | valid | N | 148 | 0.046676 | 0.040971 | 0.087647 | 269.736501 | 5.597446 |
| evolved-policy | valid | N | 148 | 0.047452 | 0.040902 | 0.088355 | 269.911971 | 5.598096 |
| increasing | valid | N | 148 | 0.047542 | 0.041943 | 0.089486 | 270.192465 | 5.599135 |

evolved-policy: 3/3 valid; S min/median/max = 268.551132/268.793252/269.911971; stdev = 0.725952.
evolved-prompt: 3/3 valid; S min/median/max = 207.397742/208.065743/209.137350; stdev = 0.877573.
increasing: 3/3 valid; S min/median/max = 269.620355/269.736501/270.192465; stdev = 0.302408.
interleaved: 3/3 valid; S min/median/max = 193.702367/193.846879/193.898884; stdev = 0.101823.
mock-prompt-seed: 3/3 valid; S min/median/max = 210.006506/211.113268/212.125325; stdev = 1.059762.
routes-short: 3/3 valid; S min/median/max = 193.669953/193.862236/194.191428; stdev = 0.263716.

## Target {5,7} — 1a0671a9d83ccda6

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| evolved-prompt | valid | N | 73 | 0.114775 | 0.041976 | 0.156751 | 200.117947 | 5.298907 |
| evolved-prompt | valid | N | 73 | 0.123815 | 0.040277 | 0.164092 | 201.387831 | 5.305233 |
| evolved-prompt | valid | N | 73 | 0.124444 | 0.041175 | 0.165619 | 201.652142 | 5.306544 |
| mock-prompt-seed | valid | N | 73 | 0.140162 | 0.039830 | 0.179992 | 204.138530 | 5.318799 |
| mock-prompt-seed | valid | N | 73 | 0.140511 | 0.040111 | 0.180622 | 204.247536 | 5.319333 |
| mock-prompt-seed | valid | N | 73 | 0.140983 | 0.039684 | 0.180667 | 204.255420 | 5.319371 |
| evolved-policy | valid | N | 136 | 0.042443 | 0.040118 | 0.082561 | 255.484480 | 5.543162 |
| evolved-policy | valid | N | 136 | 0.042300 | 0.041082 | 0.083382 | 255.678175 | 5.543920 |
| routes-short | valid | N | 136 | 0.043452 | 0.040093 | 0.083545 | 255.716729 | 5.544070 |
| interleaved | valid | N | 136 | 0.043341 | 0.040941 | 0.084282 | 255.890500 | 5.544750 |
| routes-short | valid | N | 136 | 0.044780 | 0.039519 | 0.084299 | 255.894607 | 5.544766 |
| routes-short | valid | N | 136 | 0.043491 | 0.041049 | 0.084540 | 255.951516 | 5.544988 |
| interleaved | valid | N | 136 | 0.044433 | 0.040281 | 0.084714 | 255.992533 | 5.545148 |
| evolved-policy | valid | N | 136 | 0.044011 | 0.040979 | 0.084990 | 256.057728 | 5.545403 |
| interleaved | valid | N | 136 | 0.043711 | 0.042384 | 0.086096 | 256.318554 | 5.546421 |
| increasing | valid | N | 136 | 0.046288 | 0.041002 | 0.087290 | 256.600465 | 5.547520 |
| increasing | valid | N | 136 | 0.048089 | 0.039963 | 0.088051 | 256.780151 | 5.548220 |
| increasing | valid | N | 136 | 0.050332 | 0.038458 | 0.088790 | 256.954492 | 5.548899 |

evolved-policy: 3/3 valid; S min/median/max = 255.484480/255.678175/256.057728; stdev = 0.291603.
evolved-prompt: 3/3 valid; S min/median/max = 200.117947/201.387831/201.652142; stdev = 0.820185.
increasing: 3/3 valid; S min/median/max = 256.600465/256.780151/256.954492; stdev = 0.177020.
interleaved: 3/3 valid; S min/median/max = 255.890500/255.992533/256.318554; stdev = 0.223581.
mock-prompt-seed: 3/3 valid; S min/median/max = 204.138530/204.247536/204.255420; stdev = 0.065330.
routes-short: 3/3 valid; S min/median/max = 255.716729/255.894607/255.951516; stdev = 0.122477.

## Target {4,6,9} — 20d893dff68971b9

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| interleaved | valid | N | 77 | 0.041365 | 0.039865 | 0.081230 | 191.377723 | 5.254249 |
| routes-short | valid | N | 77 | 0.042533 | 0.039879 | 0.082412 | 191.587012 | 5.255342 |
| interleaved | valid | N | 77 | 0.042261 | 0.040385 | 0.082646 | 191.628387 | 5.255558 |
| routes-short | valid | N | 77 | 0.043172 | 0.040197 | 0.083369 | 191.756308 | 5.256225 |
| routes-short | valid | N | 77 | 0.043769 | 0.039602 | 0.083371 | 191.756660 | 5.256227 |
| interleaved | valid | N | 77 | 0.043318 | 0.041414 | 0.084732 | 191.997567 | 5.257483 |
| evolved-prompt | valid | N | 77 | 0.125096 | 0.039508 | 0.164604 | 206.134845 | 5.328531 |
| evolved-prompt | valid | N | 77 | 0.125471 | 0.039624 | 0.165094 | 206.221707 | 5.328952 |
| evolved-prompt | valid | N | 77 | 0.124692 | 0.041793 | 0.166485 | 206.467800 | 5.330144 |
| mock-prompt-seed | valid | N | 77 | 0.137674 | 0.041030 | 0.178704 | 208.630585 | 5.340565 |
| mock-prompt-seed | valid | N | 77 | 0.139956 | 0.040337 | 0.180293 | 208.911847 | 5.341912 |
| mock-prompt-seed | valid | N | 77 | 0.142976 | 0.040757 | 0.183733 | 209.520709 | 5.344823 |
| evolved-policy | valid | N | 147 | 0.041638 | 0.040101 | 0.081739 | 267.189567 | 5.587958 |
| evolved-policy | valid | N | 147 | 0.042716 | 0.040124 | 0.082840 | 267.461407 | 5.588975 |
| evolved-policy | valid | N | 147 | 0.041320 | 0.041746 | 0.083066 | 267.517318 | 5.589184 |
| increasing | valid | N | 147 | 0.044704 | 0.039454 | 0.084158 | 267.787091 | 5.590192 |
| increasing | valid | N | 147 | 0.044890 | 0.039426 | 0.084316 | 267.826073 | 5.590338 |
| increasing | valid | N | 147 | 0.046806 | 0.040450 | 0.087255 | 268.552095 | 5.593045 |

evolved-policy: 3/3 valid; S min/median/max = 267.189567/267.461407/267.517318; stdev = 0.175330.
evolved-prompt: 3/3 valid; S min/median/max = 206.134845/206.221707/206.467800; stdev = 0.172707.
increasing: 3/3 valid; S min/median/max = 267.787091/267.826073/268.552095; stdev = 0.430864.
interleaved: 3/3 valid; S min/median/max = 191.377723/191.628387/191.997567; stdev = 0.311804.
mock-prompt-seed: 3/3 valid; S min/median/max = 208.630585/208.911847/209.520709; stdev = 0.454999.
routes-short: 3/3 valid; S min/median/max = 191.587012/191.756308/191.756660; stdev = 0.097845.

## Target {8,9} — 86023d729765c14f

| Competitor | Status | Outcome | C | Discovery CPU | Verification CPU | T | S | log_score |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| evolved-prompt | valid | N | 73 | 0.118054 | 0.040953 | 0.159007 | 200.508239 | 5.300855 |
| evolved-prompt | valid | N | 73 | 0.126781 | 0.040210 | 0.166991 | 201.889509 | 5.307721 |
| evolved-prompt | valid | N | 73 | 0.130798 | 0.041111 | 0.171909 | 202.740258 | 5.311926 |
| mock-prompt-seed | valid | N | 73 | 0.138237 | 0.040739 | 0.178977 | 203.962948 | 5.317938 |
| mock-prompt-seed | valid | N | 73 | 0.144021 | 0.039573 | 0.183594 | 204.761839 | 5.321848 |
| mock-prompt-seed | valid | N | 73 | 0.145432 | 0.040419 | 0.185851 | 205.152194 | 5.323752 |
| interleaved | valid | N | 139 | 0.052775 | 0.040221 | 0.092997 | 261.226176 | 5.565387 |
| routes-short | valid | N | 139 | 0.053189 | 0.040072 | 0.093261 | 261.289465 | 5.565629 |
| routes-short | valid | N | 139 | 0.053066 | 0.040276 | 0.093342 | 261.308673 | 5.565702 |
| interleaved | valid | N | 139 | 0.052316 | 0.041062 | 0.093379 | 261.317519 | 5.565736 |
| routes-short | valid | N | 139 | 0.054101 | 0.039373 | 0.093474 | 261.340342 | 5.565824 |
| interleaved | valid | N | 139 | 0.053826 | 0.039689 | 0.093514 | 261.349962 | 5.565860 |
| evolved-policy | valid | N | 139 | 0.058586 | 0.039489 | 0.098075 | 262.439893 | 5.570022 |
| evolved-policy | valid | N | 139 | 0.058260 | 0.039940 | 0.098201 | 262.470008 | 5.570137 |
| evolved-policy | valid | N | 139 | 0.060223 | 0.040849 | 0.101072 | 263.156241 | 5.572748 |
| increasing | valid | N | 139 | 0.084736 | 0.042434 | 0.127170 | 269.393549 | 5.596173 |
| increasing | valid | N | 139 | 0.087891 | 0.040582 | 0.128473 | 269.704972 | 5.597329 |
| increasing | valid | N | 139 | 0.090068 | 0.041414 | 0.131481 | 270.424068 | 5.599991 |

evolved-policy: 3/3 valid; S min/median/max = 262.439893/262.470008/263.156241; stdev = 0.405171.
evolved-prompt: 3/3 valid; S min/median/max = 200.508239/201.889509/202.740258; stdev = 1.126468.
increasing: 3/3 valid; S min/median/max = 269.393549/269.704972/270.424068; stdev = 0.528528.
interleaved: 3/3 valid; S min/median/max = 261.226176/261.317519/261.349962; stdev = 0.064186.
mock-prompt-seed: 3/3 valid; S min/median/max = 203.962948/204.761839/205.152194; stdev = 0.606206.
routes-short: 3/3 valid; S min/median/max = 261.289465/261.308673/261.340342; stdev = 0.025692.

## Coverage (separate from per-target scores)

- evolved-policy: 4/4 distinct tasks solved.
- evolved-prompt: 4/4 distinct tasks solved.
- increasing: 4/4 distinct tasks solved.
- interleaved: 4/4 distinct tasks solved.
- mock-prompt-seed: 4/4 distinct tasks solved.
- routes-short: 4/4 distinct tasks solved.
